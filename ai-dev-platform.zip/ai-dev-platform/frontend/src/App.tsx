import React, { useState } from "react";
import { Toaster } from "react-hot-toast";
import { PanelLeft, TerminalSquare, Menu } from "lucide-react";
import { AppProvider, useApp } from "./context/AppContext";
import { useResponsive } from "./hooks/useResponsive";
import { ChatInterface } from "./components/Chat/ChatInterface";
import { CodePreview } from "./components/Code/CodePreview";
import { ProjectManager } from "./components/Project/ProjectManager";
import { TerminalPanel } from "./components/Terminal/Terminal";

function TopBar() {
  const { currentProject, showTerminal, setShowTerminal } = useApp();
  const [sidebarOpenMobile, setSidebarOpenMobile] = useState(false);

  return (
    <div className="h-12 shrink-0 border-b border-white/10 flex items-center justify-between px-3">
      <div className="flex items-center gap-2 min-w-0">
        <button
          className="lg:hidden p-1.5 rounded hover:bg-surface"
          onClick={() => setSidebarOpenMobile((v) => !v)}
        >
          <Menu className="w-4 h-4" />
        </button>
        <PanelLeft className="w-4 h-4 text-primary hidden lg:block" />
        <span className="text-sm font-medium truncate">
          {currentProject ? currentProject.name : "AI Dev Platform"}
        </span>
      </div>
      <button
        onClick={() => setShowTerminal(!showTerminal)}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-white/10 ${
          showTerminal ? "bg-primary text-[#0D1117]" : "hover:bg-surface"
        }`}
      >
        <TerminalSquare className="w-3.5 h-3.5" /> Terminal
      </button>
    </div>
  );
}

function DesktopLayout() {
  const { showTerminal } = useApp();
  return (
    <div className="flex flex-col h-screen">
      <TopBar />
      <div className="flex flex-1 min-h-0">
        <div className="w-64 border-r border-white/10 shrink-0">
          <ProjectManager />
        </div>
        <div className="w-[420px] border-r border-white/10 shrink-0">
          <ChatInterface />
        </div>
        <div className="flex-1 flex flex-col min-w-0">
          <div className={showTerminal ? "flex-1 min-h-0" : "flex-1"}>
            <CodePreview />
          </div>
          {showTerminal && (
            <div className="h-64 border-t border-white/10 shrink-0">
              <TerminalPanel />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MobileLayout() {
  const [tab, setTab] = useState<"chat" | "code" | "projects" | "terminal">("chat");

  return (
    <div className="flex flex-col h-screen">
      <TopBar />
      <div className="flex-1 min-h-0">
        {tab === "chat" && <ChatInterface />}
        {tab === "code" && <CodePreview />}
        {tab === "projects" && <ProjectManager />}
        {tab === "terminal" && <TerminalPanel />}
      </div>
      <div className="h-14 shrink-0 border-t border-white/10 flex items-stretch">
        {(["projects", "chat", "code", "terminal"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 text-xs capitalize ${tab === t ? "text-primary" : "text-gray-500"}`}
          >
            {t}
          </button>
        ))}
      </div>
    </div>
  );
}

function Shell() {
  const { isDesktop } = useResponsive();
  return isDesktop ? <DesktopLayout /> : <MobileLayout />;
}

export default function App() {
  return (
    <AppProvider>
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: "#161B22", color: "#F0F6FC", border: "1px solid rgba(255,255,255,0.1)" }
        }}
      />
      <Shell />
    </AppProvider>
  );
}
