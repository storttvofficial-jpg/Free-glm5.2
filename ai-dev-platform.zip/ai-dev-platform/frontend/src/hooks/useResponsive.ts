import { useEffect, useState } from "react";

export function useResponsive() {
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    const onResize = () => setWidth(window.innerWidth);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return {
    width,
    isDesktop: width > 1024,
    isTablet: width > 768 && width <= 1024,
    isMobile: width <= 768
  };
}
