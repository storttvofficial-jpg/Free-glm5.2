import type { Message, Project, ProjectSummary, UploadedFile } from "../types";

const BASE = "/api";

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      message = body.message || message;
    } catch {
      // ignore parse failure
    }
    throw new Error(message);
  }
  return res.json();
}

export const api = {
  createProject: (name?: string) =>
    fetch(`${BASE}/create-project`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    }).then((r) => json<Project>(r)),

  listProjects: () => fetch(`${BASE}/projects`).then((r) => json<ProjectSummary[]>(r)),

  getProject: (id: string) => fetch(`${BASE}/project/${id}`).then((r) => json<Project>(r)),

  saveProject: (id: string, updates: Partial<Project>) =>
    fetch(`${BASE}/project/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates)
    }).then((r) => json<Project>(r)),

  deleteProject: (id: string) =>
    fetch(`${BASE}/project/${id}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  uploadFiles: (files: File[]) => {
    const formData = new FormData();
    files.forEach((f) => formData.append("files", f));
    return fetch(`${BASE}/upload`, { method: "POST", body: formData }).then((r) =>
      json<{ files: UploadedFile[] }>(r)
    );
  },

  exportProject: async (id: string) => {
    const res = await fetch(`${BASE}/export/${id}`);
    if (!res.ok) throw new Error("Export failed");
    return res.blob();
  }
};

/**
 * Opens a real SSE stream to /api/chat and invokes the provided callbacks
 * as events arrive. Returns an abort() function to cancel the stream.
 */
export function streamChat(
  messages: Pick<Message, "role" | "content">[],
  handlers: {
    onStatus?: (status: string) => void;
    onThinking?: (delta: string) => void;
    onToken?: (delta: string) => void;
    onDone?: () => void;
    onError?: (message: string) => void;
  }
) {
  const controller = new AbortController();

  (async () => {
    try {
      const res = await fetch(`${BASE}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages }),
        signal: controller.signal
      });

      if (!res.ok || !res.body) {
        const body = await res.json().catch(() => ({}));
        handlers.onError?.(body.message || "Chat request failed");
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const raw of events) {
          const lines = raw.split("\n");
          const eventLine = lines.find((l) => l.startsWith("event:"));
          const dataLine = lines.find((l) => l.startsWith("data:"));
          if (!eventLine || !dataLine) continue;

          const eventName = eventLine.replace("event:", "").trim();
          const data = JSON.parse(dataLine.replace("data:", "").trim());

          if (eventName === "status") handlers.onStatus?.(data.status);
          else if (eventName === "thinking") handlers.onThinking?.(data.delta);
          else if (eventName === "token") handlers.onToken?.(data.delta);
          else if (eventName === "error") handlers.onError?.(data.message);
          else if (eventName === "done") handlers.onDone?.();
        }
      }
    } catch (err: any) {
      if (err.name !== "AbortError") {
        handlers.onError?.(err.message || "Stream failed");
      }
    }
  })();

  return () => controller.abort();
}
