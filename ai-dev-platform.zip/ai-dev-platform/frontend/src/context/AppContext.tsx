import React, { createContext, useContext, useState, useCallback } from "react";
import type { Message, Project, ProjectSummary } from "../types";
import { api } from "../services/api";
import toast from "react-hot-toast";

interface AppContextValue {
  projects: ProjectSummary[];
  currentProject: Project | null;
  messages: Message[];
  isStreaming: boolean;
  showCode: boolean;
  showTerminal: boolean;
  setShowCode: (v: boolean) => void;
  setShowTerminal: (v: boolean) => void;
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  setIsStreaming: (v: boolean) => void;
  refreshProjects: () => Promise<void>;
  openProject: (id: string) => Promise<void>;
  newProject: (name?: string) => Promise<Project>;
  persistFiles: (files: Record<string, string>) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [showCode, setShowCode] = useState(true);
  const [showTerminal, setShowTerminal] = useState(false);

  const refreshProjects = useCallback(async () => {
    try {
      const list = await api.listProjects();
      setProjects(list);
    } catch (err: any) {
      toast.error(`Couldn't load projects: ${err.message}`);
    }
  }, []);

  const openProject = useCallback(async (id: string) => {
    try {
      const project = await api.getProject(id);
      setCurrentProject(project);
      setMessages(project.chatHistory || []);
    } catch (err: any) {
      toast.error(`Couldn't open project: ${err.message}`);
    }
  }, []);

  const newProject = useCallback(async (name?: string) => {
    const project = await api.createProject(name);
    setCurrentProject(project);
    setMessages([]);
    await refreshProjects();
    return project;
  }, [refreshProjects]);

  const persistFiles = useCallback(
    async (files: Record<string, string>) => {
      if (!currentProject) return;
      const merged = { ...currentProject.files, ...files };
      const updated = await api.saveProject(currentProject.id, {
        files: merged,
        chatHistory: messages
      });
      setCurrentProject(updated);
    },
    [currentProject, messages]
  );

  return (
    <AppContext.Provider
      value={{
        projects,
        currentProject,
        messages,
        isStreaming,
        showCode,
        showTerminal,
        setShowCode,
        setShowTerminal,
        setMessages,
        setIsStreaming,
        refreshProjects,
        openProject,
        newProject,
        persistFiles
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
