export type MessageStatus =
  | "thinking"
  | "writing_code"
  | "editing_file"
  | "searching"
  | "complete";

export interface CodeBlock {
  language: string;
  filePath?: string;
  code: string;
}

export interface UploadedFile {
  id: string;
  originalName: string;
  storedName: string;
  size: number;
  mimeType: string;
  url: string;
}

export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  thinking?: string;
  status?: MessageStatus;
  files?: UploadedFile[];
  codeBlocks?: CodeBlock[];
  timestamp: string;
}

export interface ProjectSummary {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  fileCount: number;
}

export interface Project extends ProjectSummary {
  files: Record<string, string>;
  chatHistory: Message[];
  versionHistory: { timestamp: string; fileCount: number }[];
}
