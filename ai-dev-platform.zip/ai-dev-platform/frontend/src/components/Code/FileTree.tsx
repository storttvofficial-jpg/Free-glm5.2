import React from "react";
import { FileCode2 } from "lucide-react";

export function FileTree({
  files,
  activeFile,
  onSelect
}: {
  files: Record<string, string>;
  activeFile: string | null;
  onSelect: (path: string) => void;
}) {
  const paths = Object.keys(files).sort();

  if (paths.length === 0) {
    return <div className="text-xs text-gray-500 p-3">No files generated yet.</div>;
  }

  return (
    <div className="py-2">
      {paths.map((p) => (
        <button
          key={p}
          onClick={() => onSelect(p)}
          className={`w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs truncate hover:bg-white/5 ${
            activeFile === p ? "bg-white/10 text-primary" : "text-gray-300"
          }`}
        >
          <FileCode2 className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{p}</span>
        </button>
      ))}
    </div>
  );
}
