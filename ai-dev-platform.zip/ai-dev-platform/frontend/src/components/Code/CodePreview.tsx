import React, { useMemo, useState } from "react";
import Editor from "@monaco-editor/react";
import { Code2, Eye, Download } from "lucide-react";
import { saveAs } from "file-saver";
import toast from "react-hot-toast";
import { useApp } from "../../context/AppContext";
import { api } from "../../services/api";
import { FileTree } from "./FileTree";

function guessLanguage(path: string) {
  const ext = path.split(".").pop();
  const map: Record<string, string> = {
    ts: "typescript", tsx: "typescript", js: "javascript", jsx: "javascript",
    json: "json", css: "css", html: "html", md: "markdown", py: "python"
  };
  return map[ext || ""] || "plaintext";
}

// Builds a single-document preview for HTML/CSS/JS projects by inlining
// linked stylesheets/scripts found in files["index.html"], if present.
function buildPreviewDoc(files: Record<string, string>): string | null {
  const html = files["index.html"] || files["public/index.html"];
  if (!html) return null;

  let doc = html;
  for (const [path, content] of Object.entries(files)) {
    if (path.endsWith(".css")) {
      doc = doc.replace(
        new RegExp(`<link[^>]+href=["'].*${path.split("/").pop()}["'][^>]*>`),
        `<style>${content}</style>`
      );
    }
    if (path.endsWith(".js") && !path.includes("node_modules")) {
      doc = doc.replace(
        new RegExp(`<script[^>]+src=["'].*${path.split("/").pop()}["'][^>]*></script>`),
        `<script>${content}</script>`
      );
    }
  }
  return doc;
}

export function CodePreview() {
  const { currentProject, showCode, setShowCode } = useApp();
  const [activeFile, setActiveFile] = useState<string | null>(null);
  const files = currentProject?.files || {};

  const activePath = activeFile && files[activeFile] ? activeFile : Object.keys(files)[0] || null;
  const previewDoc = useMemo(() => buildPreviewDoc(files), [files]);

  async function handleExport() {
    if (!currentProject) return;
    try {
      const blob = await api.exportProject(currentProject.id);
      saveAs(blob, `${currentProject.name}.zip`);
      toast.success("Export downloaded");
    } catch (err: any) {
      toast.error(err.message || "Export failed");
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
        <div className="flex gap-1 bg-surface rounded-lg p-1">
          <button
            onClick={() => setShowCode(true)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs ${
              showCode ? "bg-primary text-[#0D1117]" : "text-gray-400"
            }`}
          >
            <Code2 className="w-3.5 h-3.5" /> Code
          </button>
          <button
            onClick={() => setShowCode(false)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs ${
              !showCode ? "bg-primary text-[#0D1117]" : "text-gray-400"
            }`}
          >
            <Eye className="w-3.5 h-3.5" /> Preview
          </button>
        </div>
        <button
          onClick={handleExport}
          disabled={!currentProject}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-surface border border-white/10 rounded-lg hover:bg-white/5 disabled:opacity-40"
        >
          <Download className="w-3.5 h-3.5" /> Export .zip
        </button>
      </div>

      {showCode ? (
        <div className="flex flex-1 min-h-0">
          <div className="w-52 border-r border-white/10 overflow-y-auto shrink-0">
            <FileTree files={files} activeFile={activePath} onSelect={setActiveFile} />
          </div>
          <div className="flex-1 min-w-0">
            {activePath ? (
              <Editor
                key={activePath}
                theme="vs-dark"
                path={activePath}
                language={guessLanguage(activePath)}
                value={files[activePath]}
                options={{ readOnly: true, minimap: { enabled: false }, fontSize: 13 }}
              />
            ) : (
              <div className="flex items-center justify-center h-full text-sm text-gray-500">
                No file selected
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 bg-white">
          {previewDoc ? (
            <iframe
              title="preview"
              srcDoc={previewDoc}
              sandbox="allow-scripts allow-forms allow-modals"
              className="w-full h-full border-0"
            />
          ) : (
            <div className="flex items-center justify-center h-full text-sm text-gray-500 bg-bg">
              Preview needs an index.html in the generated files.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
