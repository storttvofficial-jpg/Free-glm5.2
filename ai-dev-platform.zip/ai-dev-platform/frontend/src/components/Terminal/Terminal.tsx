import React, { useEffect, useRef } from "react";
import { Terminal as XTerm } from "xterm";
import { FitAddon } from "xterm-addon-fit";
import { io, Socket } from "socket.io-client";
import "xterm/css/xterm.css";
import { useApp } from "../../context/AppContext";

// Real terminal: connects over Socket.IO to a node-pty process on the backend.
export function TerminalPanel() {
  const { currentProject } = useApp();
  const containerRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket>();
  const termRef = useRef<XTerm>();

  useEffect(() => {
    if (!containerRef.current) return;

    const term = new XTerm({
      theme: {
        background: "#0D1117",
        foreground: "#F0F6FC",
        cursor: "#58A6FF"
      },
      fontSize: 13,
      fontFamily: "JetBrains Mono, Menlo, monospace",
      convertEol: true
    });
    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(containerRef.current);
    fitAddon.fit();
    termRef.current = term;

    const socket = io({ path: "/socket.io" });
    socketRef.current = socket;

    socket.on("connect", () => {
      socket.emit("terminal:start", { projectId: currentProject?.id });
    });

    socket.on("terminal:output", (data: string) => term.write(data));
    socket.on("terminal:error", (msg: string) => term.write(`\r\n\x1b[31m${msg}\x1b[0m\r\n`));

    term.onData((data) => socket.emit("terminal:input", data));

    const handleResize = () => {
      fitAddon.fit();
      socket.emit("terminal:resize", { cols: term.cols, rows: term.rows });
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      socket.emit("terminal:stop");
      socket.disconnect();
      term.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProject?.id]);

  return <div ref={containerRef} className="h-full w-full bg-bg px-2 py-1" />;
}
