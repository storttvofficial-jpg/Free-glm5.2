import React, { useRef, useState } from "react";
import { Send, Paperclip, Square } from "lucide-react";
import toast from "react-hot-toast";
import { useApp } from "../../context/AppContext";
import { api, streamChat } from "../../services/api";
import { parseCodeBlocks } from "../../utils/codeParser";
import { MessageBubble } from "./MessageBubble";
import type { Message, UploadedFile } from "../../types";

export function ChatInterface() {
  const { messages, setMessages, isStreaming, setIsStreaming, currentProject, persistFiles } = useApp();
  const [input, setInput] = useState("");
  const [pendingFiles, setPendingFiles] = useState<UploadedFile[]>([]);
  const abortRef = useRef<() => void>();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () =>
    requestAnimationFrame(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }));

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    if (files.length > 20) {
      toast.error("Max 20 files at once");
      return;
    }
    try {
      const { files: uploaded } = await api.uploadFiles(files);
      setPendingFiles((prev) => [...prev, ...uploaded]);
      toast.success(`Uploaded ${uploaded.length} file(s)`);
    } catch (err: any) {
      toast.error(err.message || "Upload failed");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleSend() {
    if (!input.trim() && pendingFiles.length === 0) return;
    if (!currentProject) {
      toast.error("Create or open a project first");
      return;
    }

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: input,
      files: pendingFiles,
      timestamp: new Date().toISOString()
    };

    const assistantMessage: Message = {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "",
      thinking: "",
      status: "thinking",
      timestamp: new Date().toISOString()
    };

    const nextMessages = [...messages, userMessage, assistantMessage];
    setMessages(nextMessages);
    setInput("");
    setPendingFiles([]);
    setIsStreaming(true);
    scrollToBottom();

    const conversationForApi = [...messages, userMessage].map((m) => ({
      role: m.role,
      content: m.content
    }));

    abortRef.current = streamChat(conversationForApi, {
      onStatus: (status) => {
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantMessage.id ? { ...m, status: status as any } : m))
        );
      },
      onThinking: (delta) => {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMessage.id ? { ...m, thinking: (m.thinking || "") + delta } : m
          )
        );
        scrollToBottom();
      },
      onToken: (delta) => {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMessage.id ? { ...m, content: m.content + delta } : m
          )
        );
        scrollToBottom();
      },
      onDone: async () => {
        setIsStreaming(false);
        setMessages((prev) => {
          const final = prev.map((m) => (m.id === assistantMessage.id ? { ...m, status: "complete" as const } : m));
          const assistantFinal = final.find((m) => m.id === assistantMessage.id);
          if (assistantFinal) {
            const blocks = parseCodeBlocks(assistantFinal.content);
            const fileMap: Record<string, string> = {};
            blocks.forEach((b, i) => {
              if (b.filePath) fileMap[b.filePath] = b.code;
            });
            if (Object.keys(fileMap).length > 0) {
              persistFiles(fileMap).catch((e) => toast.error(e.message));
            }
          }
          return final;
        });
      },
      onError: (message) => {
        setIsStreaming(false);
        toast.error(message);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMessage.id
              ? { ...m, status: "complete" as const, content: m.content || `_Error: ${message}_` }
              : m
          )
        );
      }
    });
  }

  function handleStop() {
    abortRef.current?.();
    setIsStreaming(false);
  }

  return (
    <div className="flex flex-col h-full">
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        {messages.length === 0 && (
          <div className="text-gray-500 text-sm text-center mt-12">
            {currentProject
              ? "Describe what you'd like to build."
              : "Create or open a project to start chatting."}
          </div>
        )}
        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} />
        ))}
      </div>

      {pendingFiles.length > 0 && (
        <div className="px-4 pb-2 flex flex-wrap gap-2">
          {pendingFiles.map((f) => (
            <span key={f.id} className="text-xs px-2 py-1 bg-surface border border-white/10 rounded">
              {f.originalName}
            </span>
          ))}
        </div>
      )}

      <div className="border-t border-white/10 p-3 flex items-end gap-2">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFileSelect}
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="p-2.5 rounded-lg hover:bg-surface text-gray-400 shrink-0"
          title="Attach files"
        >
          <Paperclip className="w-5 h-5" />
        </button>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          placeholder="Ask the AI to build or edit something..."
          rows={1}
          className="flex-1 bg-surface border border-white/10 rounded-lg px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-primary min-h-[44px] max-h-40"
        />
        {isStreaming ? (
          <button
            onClick={handleStop}
            className="p-2.5 rounded-lg bg-danger text-white shrink-0"
            title="Stop generating"
          >
            <Square className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={handleSend}
            className="p-2.5 rounded-lg bg-primary text-[#0D1117] shrink-0 disabled:opacity-40"
            disabled={!input.trim() && pendingFiles.length === 0}
            title="Send"
          >
            <Send className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
