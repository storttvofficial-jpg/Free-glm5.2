import React, { useState } from "react";
import { ChevronDown, ChevronRight, Brain } from "lucide-react";

export function ThinkingDisplay({ thinking }: { thinking: string }) {
  const [open, setOpen] = useState(false);
  if (!thinking) return null;

  return (
    <div className="mb-2 border border-white/10 rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-400 hover:text-gray-300 bg-surface transition-colors"
      >
        {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        <Brain className="w-4 h-4" />
        <span>Reasoning</span>
      </button>
      {open && (
        <div className="px-3 py-2 text-sm text-gray-400 bg-bg whitespace-pre-wrap font-mono border-t border-white/10">
          {thinking}
        </div>
      )}
    </div>
  );
}
