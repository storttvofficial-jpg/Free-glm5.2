import React from "react";
import { Loader2, Code2, FilePenLine, Search, CheckCircle2 } from "lucide-react";
import type { MessageStatus } from "../../types";

const STATUS_CONFIG: Record<MessageStatus, { label: string; icon: React.ReactNode }> = {
  thinking: { label: "Thinking...", icon: <Loader2 className="w-4 h-4 animate-spin" /> },
  writing_code: { label: "Writing code...", icon: <Code2 className="w-4 h-4" /> },
  editing_file: { label: "Editing files...", icon: <FilePenLine className="w-4 h-4" /> },
  searching: { label: "Searching...", icon: <Search className="w-4 h-4 animate-spin" /> },
  complete: { label: "Complete", icon: <CheckCircle2 className="w-4 h-4 text-success" /> }
};

export function StatusIndicator({ status }: { status: MessageStatus }) {
  const cfg = STATUS_CONFIG[status];
  if (!cfg) return null;
  return (
    <div
      className={`inline-flex items-center gap-2 text-sm px-2.5 py-1 rounded-full bg-surface border border-white/10 ${
        status !== "complete" ? "thinking-pulse" : ""
      }`}
    >
      {cfg.icon}
      <span>{cfg.label}</span>
    </div>
  );
}
