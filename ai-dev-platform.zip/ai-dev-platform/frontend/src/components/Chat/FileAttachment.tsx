import React from "react";
import { FileText, Image as ImageIcon } from "lucide-react";
import type { UploadedFile } from "../../types";

export function FileAttachment({ file }: { file: UploadedFile }) {
  const isImage = file.mimeType.startsWith("image/");
  return (
    <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-md bg-surface border border-white/10 text-sm max-w-[220px]">
      {isImage ? (
        <img src={file.url} alt={file.originalName} className="w-8 h-8 object-cover rounded" />
      ) : (
        <FileText className="w-4 h-4 text-primary shrink-0" />
      )}
      <span className="truncate">{file.originalName}</span>
    </div>
  );
}
