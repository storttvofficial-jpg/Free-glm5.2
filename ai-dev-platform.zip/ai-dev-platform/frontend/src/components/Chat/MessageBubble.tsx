import React from "react";
import ReactMarkdown from "react-markdown";
import type { Message } from "../../types";
import { ThinkingDisplay } from "./ThinkingDisplay";
import { StatusIndicator } from "./StatusIndicator";
import { FileAttachment } from "./FileAttachment";

export function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-4`}>
      <div className={`max-w-[85%] ${isUser ? "" : "w-full"}`}>
        {!isUser && message.thinking && <ThinkingDisplay thinking={message.thinking} />}

        {!isUser && message.status && message.status !== "complete" && (
          <div className="mb-2">
            <StatusIndicator status={message.status} />
          </div>
        )}

        {message.files && message.files.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {message.files.map((f) => (
              <FileAttachment key={f.id} file={f} />
            ))}
          </div>
        )}

        {message.content && (
          <div
            className={`rounded-xl px-4 py-3 text-sm leading-relaxed ${
              isUser ? "bg-primary text-[#0D1117]" : "bg-surface border border-white/10"
            }`}
          >
            <div className="prose prose-invert prose-sm max-w-none prose-pre:bg-bg prose-pre:border prose-pre:border-white/10">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
