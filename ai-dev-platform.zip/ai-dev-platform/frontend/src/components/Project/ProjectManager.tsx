import React, { useEffect, useState } from "react";
import { Plus, FolderOpen, FileCode2 } from "lucide-react";
import toast from "react-hot-toast";
import { useApp } from "../../context/AppContext";

export function ProjectManager() {
  const { projects, currentProject, refreshProjects, openProject, newProject } = useApp();
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    refreshProjects();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreate() {
    setCreating(true);
    try {
      await newProject();
      toast.success("Project created");
    } catch (err: any) {
      toast.error(err.message || "Couldn't create project");
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-white/10">
        <button
          onClick={handleCreate}
          disabled={creating}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-primary text-[#0D1117] text-sm font-medium disabled:opacity-50"
        >
          <Plus className="w-4 h-4" /> New Project
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {projects.length === 0 && (
          <div className="text-xs text-gray-500 p-3">No projects yet.</div>
        )}
        {projects.map((p) => (
          <button
            key={p.id}
            onClick={() => openProject(p.id)}
            className={`w-full text-left px-3 py-2.5 border-b border-white/5 hover:bg-white/5 ${
              currentProject?.id === p.id ? "bg-white/10" : ""
            }`}
          >
            <div className="flex items-center gap-2 text-sm truncate">
              <FolderOpen className="w-3.5 h-3.5 shrink-0 text-primary" />
              <span className="truncate">{p.name}</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-gray-500 mt-0.5 pl-5.5">
              <FileCode2 className="w-3 h-3" />
              {p.fileCount} files · {new Date(p.updatedAt).toLocaleDateString()}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
