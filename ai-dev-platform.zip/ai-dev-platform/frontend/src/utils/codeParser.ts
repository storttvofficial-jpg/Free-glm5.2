import type { CodeBlock } from "../types";

// Parses fenced code blocks out of streamed markdown content.
// Recognizes an optional "File: path/to/file.ext" marker on the line
// immediately before a fence, which the backend's system prompt asks for.
export function parseCodeBlocks(markdown: string): CodeBlock[] {
  const blocks: CodeBlock[] = [];
  const lines = markdown.split("\n");
  let i = 0;

  while (i < lines.length) {
    const fenceMatch = lines[i].match(/^```(\w+)?/);
    if (fenceMatch) {
      const language = fenceMatch[1] || "text";
      let filePath: string | undefined;
      const prevLine = lines[i - 1] || "";
      const fileMatch = prevLine.match(/File:\s*(.+)/i);
      if (fileMatch) filePath = fileMatch[1].trim();

      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) {
        codeLines.push(lines[i]);
        i++;
      }
      blocks.push({ language, filePath, code: codeLines.join("\n") });
    }
    i++;
  }

  return blocks;
}
