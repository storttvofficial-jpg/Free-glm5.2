import express from "express";
import http from "http";
import cors from "cors";
import dotenv from "dotenv";
import { Server as SocketIOServer } from "socket.io";
import rateLimit from "express-rate-limit";
import fs from "fs-extra";

import chatRouter from "./routes/chat.js";
import uploadRouter from "./routes/upload.js";
import projectsRouter from "./routes/projects.js";
import exportRouter from "./routes/export.js";
import { attachTerminalHandlers } from "./lib/terminalManager.js";

dotenv.config();

const PORT = process.env.PORT || 3000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "http://localhost:5173";

const UPLOAD_DIR = process.env.UPLOAD_DIR || "./uploads";
const PROJECTS_DIR = "./projects";
fs.ensureDirSync(UPLOAD_DIR);
fs.ensureDirSync(PROJECTS_DIR);

const app = express();
const server = http.createServer(app);

const io = new SocketIOServer(server, {
  cors: { origin: CORS_ORIGIN, methods: ["GET", "POST"] }
});

app.use(cors({ origin: CORS_ORIGIN }));
app.use(express.json({ limit: "5mb" }));

const limiter = rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60000),
  max: Number(process.env.RATE_LIMIT_MAX || 100),
  standardHeaders: true,
  legacyHeaders: false
});
app.use("/api", limiter);

app.get("/api/health", (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

app.use("/api/chat", chatRouter);
app.use("/api/upload", uploadRouter);
app.use("/api", projectsRouter); // /api/create-project, /api/projects, /api/project/:id
app.use("/api/export", exportRouter);

// Static file serving for uploaded files (previews/thumbnails)
app.use("/uploads", express.static(UPLOAD_DIR));

// Real terminal sessions over websockets (node-pty)
attachTerminalHandlers(io);

// Centralized error handler — never leak stack traces, never crash the process
app.use((err, req, res, next) => {
  console.error("[API ERROR]", err);
  res.status(err.status || 500).json({
    error: true,
    message: err.publicMessage || "Something went wrong. Please try again."
  });
});

server.listen(PORT, () => {
  console.log(`AI Dev Platform backend listening on http://localhost:${PORT}`);
});
