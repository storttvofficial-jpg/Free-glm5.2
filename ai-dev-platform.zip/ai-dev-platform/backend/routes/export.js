import express from "express";
import archiver from "archiver";
import { getProject } from "../lib/projectStore.js";

const router = express.Router();

// GET /api/export/:id — streams a real .zip of every file in the project
router.get("/:id", async (req, res, next) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: true, message: "Project not found" });

    const files = project.files || {};

    res.setHeader("Content-Type", "application/zip");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${project.name.replace(/[^a-z0-9-_]/gi, "_")}.zip"`
    );

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", (err) => next(err));
    archive.pipe(res);

    if (Object.keys(files).length === 0) {
      // Nothing generated yet — still produce a valid zip with a placeholder
      archive.append("// No files generated yet.\n", { name: "README.txt" });
    } else {
      for (const [filePath, content] of Object.entries(files)) {
        archive.append(content, { name: filePath });
      }
      // Minimal real package.json if the AI didn't generate one
      if (!files["package.json"]) {
        archive.append(
          JSON.stringify(
            { name: project.name.toLowerCase().replace(/\s+/g, "-"), version: "1.0.0", private: true },
            null,
            2
          ),
          { name: "package.json" }
        );
      }
    }

    await archive.finalize();
  } catch (err) {
    next(err);
  }
});

export default router;
