import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs-extra";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

const UPLOAD_DIR = process.env.UPLOAD_DIR || "./uploads";
const MAX_FILE_SIZE = Number(process.env.MAX_FILE_SIZE || 10 * 1024 * 1024);
const MAX_FILES = Number(process.env.MAX_FILES || 20);

fs.ensureDirSync(UPLOAD_DIR);

const ALLOWED_EXTENSIONS = new Set([
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
  ".pdf", ".txt", ".md",
  ".js", ".jsx", ".ts", ".tsx", ".json", ".css", ".html",
  ".py", ".java", ".go", ".rs", ".c", ".cpp", ".sh",
  ".csv", ".yaml", ".yml"
]);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    return cb(new Error(`File type ${ext} is not allowed`));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE, files: MAX_FILES }
});

router.post("/", upload.array("files", MAX_FILES), (req, res) => {
  const files = (req.files || []).map((f) => ({
    id: path.parse(f.filename).name,
    originalName: f.originalname,
    storedName: f.filename,
    size: f.size,
    mimeType: f.mimetype,
    url: `/uploads/${f.filename}`
  }));
  res.json({ files });
});

// Multer errors (size/type/count) surface here instead of crashing the process
router.use((err, req, res, next) => {
  res.status(400).json({ error: true, message: err.message });
});

export default router;
