import express from "express";
import { streamChatCompletion } from "../lib/aiClient.js";

const router = express.Router();

const SYSTEM_PROMPT = `You are an expert full-stack coding assistant embedded in a developer platform.
When you write code, wrap each file in a fenced code block annotated with the language and, on the
line above the block, a line of the form "File: path/to/file.ext" so the client can parse out
individual files. Be concise in prose; let code speak for itself.`;

// POST /api/chat — real streaming completion over Server-Sent Events
router.post("/", async (req, res) => {
  const { messages } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: true, message: "messages[] is required" });
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  const send = (event, data) => {
    res.write(`event: ${event}\n`);
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  const abortController = new AbortController();
  req.on("close", () => abortController.abort());

  try {
    send("status", { status: "thinking" });

    const fullMessages = [{ role: "system", content: SYSTEM_PROMPT }, ...messages];

    let sawFirstToken = false;

    await streamChatCompletion({
      messages: fullMessages,
      signal: abortController.signal,
      onThinking: (piece) => {
        send("thinking", { delta: piece });
      },
      onToken: (piece) => {
        if (!sawFirstToken) {
          sawFirstToken = true;
          send("status", { status: "writing_code" });
        }
        send("token", { delta: piece });
      }
    });

    send("status", { status: "complete" });
    send("done", {});
  } catch (err) {
    console.error("[/api/chat] error:", err);
    send("error", { message: err.message || "AI request failed" });
  } finally {
    res.end();
  }
});

export default router;
