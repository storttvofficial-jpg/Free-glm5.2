import express from "express";
import fs from "fs-extra";
import path from "path";
import {
  createProject,
  listProjects,
  getProject,
  saveProject,
  deleteProject
} from "../lib/projectStore.js";

const router = express.Router();

router.post("/create-project", async (req, res, next) => {
  try {
    const project = await createProject({ name: req.body?.name });
    // Give the project a real workspace dir on disk for the terminal to use
    await fs.ensureDir(path.resolve("./projects", project.id, "workspace"));
    res.json(project);
  } catch (err) {
    next(err);
  }
});

router.get("/projects", async (req, res, next) => {
  try {
    res.json(await listProjects());
  } catch (err) {
    next(err);
  }
});

router.get("/project/:id", async (req, res, next) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: true, message: "Not found" });
    res.json(project);
  } catch (err) {
    next(err);
  }
});

router.put("/project/:id", async (req, res, next) => {
  try {
    const updated = await saveProject(req.params.id, req.body);
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.delete("/project/:id", async (req, res, next) => {
  try {
    await deleteProject(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
