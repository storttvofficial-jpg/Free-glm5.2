# AI Dev Platform

A real, runnable full-stack app: React/TypeScript frontend + Node/Express backend,
with genuine streaming AI chat, file upload, project persistence, a real terminal
(node-pty), and .zip export. Nothing here is mocked — every button calls a real
endpoint.

## What's real vs. simplified from the original spec

**Fully implemented and real:**
- Streaming chat via SSE, calling NVIDIA's OpenAI-compatible endpoint with your API key
- File upload (up to 20 files, 10MB each) with validation, stored on disk
- Project CRUD, persisted as JSON files on disk (survives restarts)
- Real terminal: `node-pty` spawns an actual shell per socket connection, streamed
  over Socket.IO, rendered with `xterm.js`
- Real .zip export via `archiver`, streamed to the browser
- Monaco editor for generated code, with a live iframe preview for HTML/CSS/JS projects
- Responsive desktop (>1024px) / mobile layouts

**Simplified (noted so you're not surprised):**
- No database — projects are JSON files under `backend/projects/`. Swap in Postgres/Mongo
  if you need concurrent multi-user access.
- No Puppeteer web-search integration — that requires a headless Chrome install and
  its own safety/rate-limit handling; left as a stub you can add to `routes/chat.js`.
- No auth/multi-user accounts — everything is single-tenant.
- Diff view, drag-reorder gestures, and offline service worker were left out to keep
  the codebase something you can actually read and extend; the architecture supports
  adding them.

## Prerequisites

- Node.js 18+
- An NVIDIA API key with access to the `integrate.api.nvidia.com` endpoint (or point
  `NVIDIA_BASE_URL`/`NVIDIA_MODEL` at any other OpenAI-compatible provider — the code
  doesn't care which one)

## Setup

```bash
# 1. Backend
cd backend
cp .env.example .env
# edit .env and set NVIDIA_API_KEY (and NVIDIA_MODEL if needed)
npm install
npm run dev          # starts on http://localhost:3000

# 2. Frontend (separate terminal)
cd frontend
npm install
npm run dev           # starts on http://localhost:5173
```

Open http://localhost:5173. Click **New Project**, then start chatting — the AI's
streamed response is parsed for fenced code blocks; blocks preceded by a
`File: path/to/file.ext` line are saved into the project and shown in the file tree.

## Verifying the AI integration works

```bash
curl http://localhost:3000/api/health
# {"ok":true,...}

curl -N -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Say hello in one sentence"}]}'
# should stream `event: token` lines back
```

If that curl returns a 401/403, your `NVIDIA_API_KEY` is wrong or your account
doesn't have access to the model in `NVIDIA_MODEL`.

## A note on the model name

`z-ai/glm-5.2` was in the original spec but isn't a model string I can verify exists.
The backend is written generically against the OpenAI chat-completions shape, so
swap `NVIDIA_MODEL` in `.env` for whatever model string your NVIDIA account actually
has access to (check https://build.nvidia.com for the current catalog).

## Project structure

```
backend/
  server.js              # Express app + Socket.IO + error handling
  routes/
    chat.js               # POST /api/chat — real SSE streaming completion
    upload.js              # POST /api/upload — multer file upload
    projects.js            # project CRUD, backed by lib/projectStore.js
    export.js               # GET /api/export/:id — real .zip stream
  lib/
    aiClient.js             # OpenAI SDK client pointed at NVIDIA's endpoint
    projectStore.js          # JSON-file-based persistence
    terminalManager.js        # node-pty + Socket.IO real terminal

frontend/
  src/
    components/Chat/          # chat UI, streaming status, thinking panel
    components/Code/           # Monaco editor, file tree, iframe preview
    components/Terminal/        # xterm.js + Socket.IO client
    components/Project/          # project sidebar
    context/AppContext.tsx        # global state (projects, messages, streaming)
    services/api.ts                 # fetch wrappers + hand-rolled SSE client
    hooks/                            # useResponsive, useLocalStorage, useDebounce
```

## Deploying

- Backend: any Node host (Render, Fly.io, a VPS). `node-pty` needs native compilation —
  make sure the host has build tools, or use a Docker image with `python3`, `make`,
  `g++` installed before `npm install`.
- Frontend: `npm run build` produces static files in `frontend/dist/` — deploy to
  Vercel/Netlify/any static host, and set `CORS_ORIGIN` on the backend to match.
- **Don't** run the terminal feature (`node-pty`, real shell access) on a public
  multi-tenant deployment without sandboxing each session (e.g. a container per
  project) — as written, it gives whoever's using the app a real shell on your server.
